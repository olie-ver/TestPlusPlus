#pragma once

#ifndef TESTPP_CONCEPTS_HAS_QUALITY_H
#define TESTPP_CONCEPTS_HAS_QUALITY_H

#include "operator.hpp"

#include <concepts>
#include <ranges>

namespace testpp::internal {
    namespace Concepts {
        //A concept for types that can be nullable
        template <typename T>
        concept Nullable = std::is_pointer_v<std::decay_t<T>> || //is a raw pointer or decays to a raw pointer
            std::is_null_pointer_v<std::decay_t<T>> || //or it decays to nullptr
            requires(T t) { t.get(); } || //has .get() like a smart pointer
            requires(T t) { { t.has_value() } -> std::convertible_to<bool>; }; //has .has_value() like an optional

        template <typename A>
        concept Iterable = requires()
        {
            requires std::ranges::range<A>;
        };

        //A concept for types that are iterable and the types of what they contain are comparable by ==
        template <typename A, typename B>
        concept IterableAndComparable = requires()
        {
            requires std::ranges::range<A>;
            requires std::ranges::range<B>;
            requires HasEQ<std::ranges::range_value_t<A>, std::ranges::range_value_t<B>>;
        };

        //A concept for types that are hashable
        template <typename A>
        concept Hashable = requires(A& a) {
            { std::hash<A>{}(a) } -> std::convertible_to<size_t>;
        };

        //A concept for types that have a size
        template <typename A>
        concept Sizeable = requires(A& a) {
            { a.size() } ->  std::convertible_to<size_t>;
        };
    }
}

#endif