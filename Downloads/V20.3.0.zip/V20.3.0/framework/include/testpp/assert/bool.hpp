#pragma once

#ifndef A_BOOL_H
#define A_BOOL_H

#include "../internal/pch/impl_pch.hpp"
#include "../internal/fail.hpp"

#define ASSERT_TRUE(cond) testpp::internal::Assert::assertTrue((cond), #cond, __FILE__, __LINE__)
#define ASSERT_FALSE(cond) testpp::internal::Assert::assertFalse((cond), #cond, __FILE__, __LINE__)

namespace testpp::internal {
    namespace Assert {
        /// @brief An Asserts test for asserting a true value
        /// @param cond a condition
        /// @param expr the condition as an expression
        /// @param file the file the function was called from
        /// @param line the line the function was called on
        inline void assertTrue(const bool cond, const char* expr, const char* file, const int line) {
            auto result = impl_bool::True(cond, expr, file, line);
            if (result) {
                Fail::a_fail(*result);
            }
        }

        /// @brief An Asserts test for asserting a false value
        /// @param cond a condition
        /// @param expr the condition as an expression
        /// @param file the file the function was called from
        /// @param line the line the function was called on
        inline void assertFalse(const bool cond, const char* expr, const char* file, const int line) {
            auto result = impl_bool::False(cond, expr, file, line);
            if (result) {
                Fail::a_fail(*result);
            }
        }
    }
}

#endif