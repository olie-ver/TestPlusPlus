#include "../../headers/Helpers.hpp"

#include <string>
#include <vector>

namespace testppCLI {
    std::vector<std::string> split(std::string s, const std::string& delimiter) {
        std::vector<std::string> tokens;
        size_t pos = 0;
        std::string token;
        while ((pos = s.find(delimiter)) != std::string::npos) {
            token = s.substr(0, pos);
            tokens.push_back(token);
            s.erase(0, pos + delimiter.length());
        }

        if (!s.empty()) {
            tokens.push_back(s);
        }

        return tokens;
    }

    std::string implode(const std::vector<std::filesystem::path>& strs, const std::string& glue) {
        std::string imploded;
        for (size_t i = 0; i < strs.size(); i++) {
            imploded += strs[i].string();
            imploded += glue;
        }
        return imploded;
    }

    std::string implode(const std::vector<std::string>& strs, const std::string& glue) {
        std::string imploded;
        for (size_t i = 0; i < strs.size(); i++) {
            imploded += strs[i];
            imploded += glue;
        }
        return imploded;
    }
}